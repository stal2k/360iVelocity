<div id='message' class='error view-error'>
    <p><?php printf( __( 'Unable to locate view: "%s"', 360IVELOLCITY_DOMAIN ), $view ); ?></p>
</div>
